﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question14
{
    public interface IntMath
    {
        int add(int a, int b);
        int Subtract(int a, int b);
        int Multiply(int a, int b);
        int Divide(int a, int b);
       

    }

    public interface DoubleMath
    {
        double add(double a, double b);
        double Subtract(double a, double b);
        double Multiply(double a, double b);
        double Divide(double a, double b);
        
    }


    class Program : IntMath, DoubleMath
    {
        public int add(int a,int b)
        {
            return (a+b);
        }
        public int Subtract(int a, int b)
        {
            return (a - b);
        }
        public int Multiply(int a, int b)
        {
            return (a * b);
        }
        public int Divide(int a, int b)
        {
            return (a / b);
        }


        public double add(double a,double b)
        {
            return (a+b);
        }
        public double Subtract(double a, double b)
        {
            return (a - b);
        }
        public double Multiply(double a, double b)
        {
            return (a * b);
        }
        public double Divide(double a, double b)
        {
            return (a / b);
        }

        static void Main(string[] args)
        {

            Program p = new Program();
            int Intsum;
            double Doublesum;
            Console.WriteLine("press 1.IntMath Functions 2.DoubleMath Functions");
            int temp = Convert.ToInt32(Console.ReadLine());
            if (temp == 1)
            {
                int a = 10, b = 5;
                Console.WriteLine("press 1.add 2.subtract 3.multiply 4.divide");
                int num = Convert.ToInt32(Console.ReadLine());
                switch (num)
                {
                    case 1:
                        Intsum = p.add(a,b);
                        Console.WriteLine("Sum:"+Intsum);
                        break;
                    case 2:
                        Intsum = p.Subtract(a,b);
                        Console.WriteLine("Difference:" + Intsum);
                        break;
                    case 3:
                        Intsum = p.Multiply(a,b);
                        Console.WriteLine("product:" + Intsum);
                        break;
                    case 4:
                        Intsum = p.Divide(a,b);
                        Console.WriteLine("Division:" + Intsum);
                        break;
                }
            
            }
            else if(temp==2)
            {
                double a = 23, b = 6;
                Console.WriteLine("press 1.add 2.subtract 3.multiply 4.divide");
                int num = Convert.ToInt32(Console.ReadLine());
                switch (num)
                {
                    case 1:
                        Doublesum = p.add(a,b);
                        Console.WriteLine("Sum:" + Doublesum);
                        break;
                    case 2:
                        Doublesum = p.Subtract(a, b);
                        Console.WriteLine("Difference:" + Doublesum);
                        break;
                    case 3:
                        Doublesum = p.Multiply(a, b);
                        Console.WriteLine("product:" + Doublesum);
                        break;
                    case 4:
                        Doublesum = p.Divide(a, b);
                        Console.WriteLine("Division:" + Doublesum);
                        break;
                }

            }
        }
    }

}