﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question13
{
    abstract public class Authentication
    {
        abstract public void Login();
        public void Logout()

        {
            Console.WriteLine("logging out");
        }
    
    }

    class Administrator : Authentication
    {
        public void ChangePassword()
        {
            Console.WriteLine("Administrator should change password");
        }

    public override void Login()
    {

    Console.WriteLine("Administrator login");
    ChangePassword();
    }
    }


    class User : Authentication
    {
        public void ChangeLoginStatus()
        {
            Console.WriteLine("changing user login status"); 
        }
        public override void Login()
        {
            Console.WriteLine("User Login");
            ChangeLoginStatus();
        }
    
    }

    class Program
    {
        static void Main(string[] args)
        {
            Administrator ad = new Administrator();
            ad.Login();
            User Uobj = new User();
            Uobj.Login();
            ad.Logout();
            Uobj.Logout();


        }
    }
}
