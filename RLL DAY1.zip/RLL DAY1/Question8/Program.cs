﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question8
{
    class ElectronicsProduct
    {
        int _productID;
        string _productName;

        public ElectronicsProduct()
        {
            _productID = 0;
            _productName = "Not Defined";
            Console.WriteLine("Product ID:" + _productID);
            Console.WriteLine("Product Name:" + _productName);
        }
       
    
    }
    class Mobile:ElectronicsProduct
    {
        int _mobileCode;
        string _mobileModel;

        public Mobile()
        {
            _mobileCode = 00;
            _mobileModel = "Not Defined";
            Console.WriteLine("Mobile Code:" + _mobileCode);
            Console.WriteLine("Mobile Model:" + _mobileModel);
        }
      
    }
    class Computer:ElectronicsProduct
    {
        int _computerID;
        string _computerModel;
        public Computer()
        {
            _computerID = 000;
            _computerModel = "Not Defined";
            Console.WriteLine("Computer ID:" + _computerID);
            Console.WriteLine("Computer Model:" + _computerModel);
        }

       
    }


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Electronic class inherited by Mobile");
            Mobile m = new Mobile();

            Console.WriteLine("Electronic class inherited by Computer"); 
            Computer c = new Computer();


        }
    }
}
