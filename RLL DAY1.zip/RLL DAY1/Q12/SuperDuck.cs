﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q12
{
    class SuperDuck
    {
        public virtual void Eat() 
        {
            Console.WriteLine("Eat() from SuperDuck Class");
        }
    }
}
