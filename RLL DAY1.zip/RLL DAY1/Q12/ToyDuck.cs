﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q12
{
    class ToyDuck :SuperDuck
    {
        public override void Eat()
        {
            Console.WriteLine("My food is electrons");
        }
    }
}
