﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q12
{
    class Duck
    {
        private int _option;
        public void Menu()
        {
            Console.WriteLine("Press 1 for Feeding your Duck");
            Console.WriteLine("Press 2 for Feeding your Toy Duck");
            _option = Convert.ToInt32(Console.ReadLine());

            if (_option==1)
            {
                MyDuck objMyDuck = new MyDuck();
                objMyDuck.Eat();
            }
            else if (_option == 2)
            {
                ToyDuck objtoyDuck = new ToyDuck();
                objtoyDuck.Eat();
            }
            else 
            {
                Console.WriteLine("Sorry invalid option");
            }
        }
    }
}
