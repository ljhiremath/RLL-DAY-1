﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingAssignmentDay1
{
    class Product
    {
        int _productID;
        string _productName;
        double _unitPrice;
        int _quantity;
        public void accept()
        {
            Console.WriteLine("enter details of product");
            Console.WriteLine("enter product ID");
            _productID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter product name");
            _productName = Console.ReadLine();
            Console.WriteLine("enter unit price of the product");
            _unitPrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter product quantity");
            _quantity = Convert.ToInt32(Console.ReadLine());
        }

        public void display()
        {
            Console.WriteLine("Product ID:"+_productID);
            Console.WriteLine("Product Name:"+_productName);
            Console.WriteLine("Product Unit Price:"+_unitPrice);
            Console.WriteLine("Product quantity:"+_quantity);
        
        
        }
    
    
    }
   

    class Question1
    {
        static void Main(string[] args)
        {
            Product p = new Product();
            p.accept();
            p.display();
            Console.ReadKey();
        }
    }
}
