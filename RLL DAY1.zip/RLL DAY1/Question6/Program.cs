﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question6
{
    class Product
    {
        int _productID;
        string _productName;
        double _unitPrice;
        int _quantity;
        public void accept()
        {
            Console.WriteLine("enter details of product");
            Console.WriteLine("enter product ID");
            _productID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter product name");
            _productName = Console.ReadLine();
            Console.WriteLine("enter unit price of the product");
            _unitPrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter product quantity");
            _quantity = Convert.ToInt32(Console.ReadLine());
        }

        public void display()
        {
            Console.WriteLine("Product ID:" + _productID);
            Console.WriteLine("Product Name:" + _productName);
            Console.WriteLine("Product Unit Price:" + _unitPrice);
            Console.WriteLine("Product quantity:" + _quantity);


        }


    }

    class Mobile : Product
    {
        string _cameraDetails;
        string _modelDetails;
        string _batteryDetails;

        public void getDetails()
        {

            accept();
            Console.WriteLine("enter details of Mobile");
            Console.WriteLine("enter Camera Details");
            _cameraDetails = Console.ReadLine();
            Console.WriteLine("enter Model Details");
            _modelDetails = Console.ReadLine();
            Console.WriteLine("enter Battery Details");
            _batteryDetails = Console.ReadLine();


        }
        public void showDetails()
        {
            display();
            Console.WriteLine("Camera Details:" + _cameraDetails);
            Console.WriteLine("Model Details:" + _modelDetails);
            Console.WriteLine("Battery Details:" + _batteryDetails);
        }


    }

    class SmartPhone : Mobile
    {
        string _androidVersion;
        string _memoryDetails;


       public void Get()
        {
            getDetails();
            Console.WriteLine("enter Android Version Details");
            _androidVersion = Console.ReadLine();
            Console.WriteLine("enter Memory Details");
            _memoryDetails = Console.ReadLine();
        
        }
       public void Set()
        {
            showDetails();
            Console.WriteLine("Android Version:" + _androidVersion);
            Console.WriteLine("Memory Details:" + _memoryDetails);
        
        }
    
    
    }



    class Program
    {
        static void Main(string[] args)
        {
            SmartPhone smrt = new SmartPhone();
            smrt.Get();
            smrt.Set();
            Console.ReadKey();
        }
    }
}
