﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    class Product
    {
        int _productID;
        string _productName;
        double _unitPrice;
        int _quantity;



        public int ProductID { get { return _productID; } set { _productID = value; } }
        public string ProductName { get { return _productName; } set { _productName = value; } }
        public double UnitPrice { get { return _unitPrice; } set { _unitPrice = value; } }
        public int Quantity { get { return _quantity; } set { _quantity = value; } }
        
     
        public void accept()
        {
            Console.WriteLine("enter details of product");
            Console.WriteLine("enter product ID");
            _productID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter product name");
            _productName = Console.ReadLine();
            Console.WriteLine("enter unit price of the product");
            _unitPrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter product quantity");
            _quantity = Convert.ToInt32(Console.ReadLine());
        }

        public void display()
        {
            Console.WriteLine("Product ID:" + _productID);
            Console.WriteLine("Product Name:" + _productName);
            Console.WriteLine("Product Unit Price:" + _unitPrice);
            Console.WriteLine("Product quantity:" + _quantity);


        }


    }


    class Program
    {
        static void Main(string[] args)
        {
            Product p = new Product();
            p.ProductID = 121;
            p.UnitPrice = 34.88;
            Console.WriteLine("enter product name");
            p.ProductName = Console.ReadLine();
            Console.WriteLine("enter quantity ");
            p.Quantity = Convert.ToInt32(Console.ReadLine());


            p.display();

        }
    }
}
