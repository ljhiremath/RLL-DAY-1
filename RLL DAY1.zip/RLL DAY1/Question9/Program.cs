﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question9
{
    


    class Program
    {
        public void area(int radius)
        {
           Console.WriteLine("area of circle:"+(3.14 * radius * radius));
        
        }
        public void area(int Base,double height)
        {
        Console.WriteLine("area of triangle"+ (0.5 * Base * height)); 
        }
        public void area(int lenght, int breath)
        {
            Console.WriteLine("area of reactangle"+(lenght* breath));
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            
            int val,val2;
            Console.WriteLine("press 1.Area of Circle 2.Triangle 3.Rectangle");
            int temp = Convert.ToInt32(Console.ReadLine());
            switch (temp)
            {
                case 1:
                    Console.WriteLine("enter radius");
                    val = Convert.ToInt32(Console.ReadLine());
                     p.area(val);
                   
                    break;
                case 2:
                    Console.WriteLine("enter lenght and height");
                    val = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    p.area(val,val2);
                    
                    break;
                case 3:
                    Console.WriteLine("enter base and height");
                    val = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    p.area(val, val2);
                   
                    break;
            
            }

        }
    }
}
