﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class Product
    {
        int _productID;
        string _productName;
        double _unitPrice;
        int _quantity;

        public Product()
        {
            Console.WriteLine("Default Constructor Called");
            _productID = 0;
            _productName = "Not Defined";
            _unitPrice = 0.00;
            _quantity = 0;

        }
        public Product(int _pID,string _pName,double _pUnit,int _pQuantity)
        {
            Console.WriteLine("Parametrized Constructor Called");
            this._productID = _pID;
            this._productName = _pName;
            this._unitPrice = _pUnit;
            this._quantity = _pQuantity;
        }


        public void accept()
        {
            Console.WriteLine("enter details of product");
            Console.WriteLine("enter product ID");
            _productID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter product name");
            _productName = Console.ReadLine();
            Console.WriteLine("enter unit price of the product");
            _unitPrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter product quantity");
            _quantity = Convert.ToInt32(Console.ReadLine());
        }

        public void display()
        {
            Console.WriteLine("Product ID:" + _productID);
            Console.WriteLine("Product Name:" + _productName);
            Console.WriteLine("Product Unit Price:" + _unitPrice);
            Console.WriteLine("Product quantity:" + _quantity);


        }


    }

    class Program
    {
        static void Main(string[] args)
        {
            Product p = new Product();
            p.display();
            Product p1 = new Product(121, "Wipro", 1212, 22);
            p1.display();
            p.accept();
            p.display();
        }
    }
}
