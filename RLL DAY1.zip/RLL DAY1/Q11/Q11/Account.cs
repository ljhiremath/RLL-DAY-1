﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q11
{
    class Account
    {
        public int AccountID { get; set; }
        public string AccountName { get; set; }
        public double AccountBalance { get; set; }

        public void DisplayBalance() 
        {
        
        }
        public virtual void Deposit() { }
        public virtual void Withdraw() { }
    }
}
