﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q11
{
    class CurrentAccount : Account
    {
        public override void Deposit()
        {
            Console.WriteLine("Deposit in current account");
        }
        public override void Withdraw()
        {
            Console.WriteLine("Withraw from current account");
        }
    }
}
