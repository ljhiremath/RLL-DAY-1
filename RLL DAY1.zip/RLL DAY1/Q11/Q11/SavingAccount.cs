﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q11
{
    class SavingAccount : Account
    {
        public override void Deposit()
        {
            Console.WriteLine("Deposit in saving account");
        }
        public override void Withdraw()
        {
            Console.WriteLine("Withraw from saving account");
        }
    }
}
