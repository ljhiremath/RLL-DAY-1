﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q11
{
    class Program
    {
        static void Main(string[] args)
        {
            SavingAccount objSavingAccount = new SavingAccount();
            Console.WriteLine("Saving Account");
            objSavingAccount.Deposit();
            objSavingAccount.Withdraw();
            CurrentAccount objCurentAccount = new CurrentAccount();
            Console.WriteLine("Current Account");
            objCurentAccount.Deposit();
            objCurentAccount.Withdraw();
        }
    }
}
