﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question7
{
  class Father
    {
       void fatherFunction();
    
    
    }
    class Mother
    {
        void motherFunction();
    }

    public class Child : Father, Mother
    {
        int _childAge;    
      //  public int ChildAge { get { return _childAge; } set { _childAge = 10; } }
        public void fatherFunction()
        {
            Console.WriteLine("inside Father's class function");
        
        }
        public void motherFunction()
        {
            Console.WriteLine("inside Mother's class function");
        }
    
    
    }


    class Program
    {
        static void Main(string[] args)
        {
            Child Cobj = new Child();
            Cobj.fatherFunction();
            Cobj.motherFunction();
        }
    }
}
