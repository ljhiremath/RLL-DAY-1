﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question4
{
    class Employee
    {
        public int EmployeeID { get; set; }
        public String EmployeeName { get; set; }
        public Double EmployeeSalary { get; set; }
    }



    class Program
    {
        static void Main(string[] args)
        {
            Employee e = new Employee();
            e.EmployeeID = 122;
            e.EmployeeName = "Himanshu"; 
            e.EmployeeSalary=34243;

            Console.WriteLine("Employee ID:"+e.EmployeeID);
            Console.WriteLine("Employee Name:"+e.EmployeeName);
            Console.WriteLine("Employee Salary:"+e.EmployeeSalary);
            Console.ReadKey();
        }
    }
}
