﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Question19
{
    public partial class frmPDetails : Form
    {
        public frmPDetails()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string connectionStr =ConfigurationManager.ConnectionStrings["demo"].ConnectionString;
            SqlConnection conn = new SqlConnection(connectionStr);
            try
            {
                conn.Open();
                string sqlCheck = "select ProductName from ProductDetails where ProductID=@ID";
                SqlCommand cmdCheck = new SqlCommand(sqlCheck, conn);
                cmdCheck.Parameters.Add("@ID", SqlDbType.Int).Value =Convert.ToInt32(txtPID.Text);
                SqlDataReader dr = cmdCheck.ExecuteReader();
                if (dr.HasRows)
                {
                 
                    MessageBox.Show("Product already exists");
                }
                else
                {
                    dr.Close();
                    string sqlInsert = "insert into ProductDetails values (@PID,@PName,@UnitPrice,@Qty)";
                    SqlCommand cmd = new SqlCommand(sqlInsert, conn);
                    cmd.Parameters.Add("@PID", SqlDbType.Int).Value = txtPID.Text;
                    cmd.Parameters.Add("@PName", SqlDbType.VarChar, 50).Value = txtPName.Text;
                    cmd.Parameters.Add("@UnitPrice", SqlDbType.Money).Value = txtUnitPrice.Text;
                    cmd.Parameters.Add("@Qty", SqlDbType.Int).Value = txtQty.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Inserted Successfully");
                    txtPID.Clear();
                    txtPName.Clear();
                    txtUnitPrice.Clear();
                    txtQty.Clear();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string connectionStr = ConfigurationManager.ConnectionStrings["demo"].ConnectionString;
            SqlConnection conn = new SqlConnection(connectionStr);
            try
            {
                conn.Open();
                string sqlCheck = "select ProductName from ProductDetails where ProductID=@ID";
                SqlCommand cmdCheck = new SqlCommand(sqlCheck, conn);
                cmdCheck.Parameters.Add("@ID", SqlDbType.Int).Value = Convert.ToInt32(txtPID.Text);
                SqlDataReader dr = cmdCheck.ExecuteReader();
                if (!dr.HasRows)
                {

                    MessageBox.Show("No Product");
                }
                else
                {
                    dr.Close();
                    string sqlInsert = "delete from ProductDetails where ProductID=@PID";
                    SqlCommand cmd = new SqlCommand(sqlInsert, conn);
                    cmd.Parameters.Add("@PID", SqlDbType.Int).Value = txtPID.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Deleted Successfully");
                    txtPID.Clear();
                    
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string connectionStr = ConfigurationManager.ConnectionStrings["demo"].ConnectionString;
            SqlConnection conn = new SqlConnection(connectionStr);
            try
            {
                conn.Open();
                string sqlCheck = "select ProductName from ProductDetails where ProductID=@ID";
                SqlCommand cmdCheck = new SqlCommand(sqlCheck, conn);
                cmdCheck.Parameters.Add("@ID", SqlDbType.Int).Value = Convert.ToInt32(txtPID.Text);
                SqlDataReader dr = cmdCheck.ExecuteReader();
                if (!dr.HasRows)
                {

                    MessageBox.Show("Product donot exists");
                }
                else
                {
                    dr.Close();
                    string sqlInsert = "update ProductDetails set ProductName=@PName,UnitPrice=@UnitPrice,Quantity=@Qty where ProductID=@PID";
                    SqlCommand cmd = new SqlCommand(sqlInsert, conn);
                    cmd.Parameters.Add("@PID", SqlDbType.Int).Value = txtPID.Text;
                    cmd.Parameters.Add("@PName", SqlDbType.VarChar, 50).Value = txtPName.Text;
                    cmd.Parameters.Add("@UnitPrice", SqlDbType.Money).Value = txtUnitPrice.Text;
                    cmd.Parameters.Add("@Qty", SqlDbType.Int).Value = txtQty.Text;
                    cmd.ExecuteReader();
                    MessageBox.Show("Updated Successfully");
                    txtPID.Clear();
                    txtPName.Clear();
                    txtUnitPrice.Clear();
                    txtQty.Clear();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            
        }
    }
}
